﻿//James Richards
//06/07/2019
//version 1.0
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algebratic
{
    public class Class
    {

        //receives a double then returns the square root of that number
        public static double SQRT(double a)
        {
            if (a > 0)
            {
                double root = a / 3;
                int i;
                for (i = 0; i < 32; i++)
                    root = (root + a / root) / 2;
                return root;
            }
            else
            {   //the square root cannot be found for zero
                throw new Exception("Number Must be Above 0");
            }
        }
        //receives a double then returns the cube of that number
        public static double Cube(double a)
        {
            if (a == 0)
            {
                return 1.0;
            }
            else
            {   //math library used to find the cube
                return Math.Pow(a, (1.0 / 3.0));
            }
        }
        //receives a double then returns the Inversion of that number
        public static double Inver(double a)
        {
            if (a == 0)
            {   //zero is an invalid input
                throw new Exception("Input Error");
            }
            else
            {
                return 1 / a;
            }
        }

    }
}
