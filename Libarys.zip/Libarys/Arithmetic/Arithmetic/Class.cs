﻿//James Richards
//06/07/2019
//version 1.0
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arithmetic
{
    public class Class
    {   
        //returns A plus B
        public static double Add(double a, double b)
        {
            return (a + b);
        }
        //returns A take B
        public static double Sub(double a, double b)
        {
            return (a - b);
        }
        //returns A divide B
        public static double Div(double a, double b)
        {
            if (b == 0)
            {   //prevent error from dividing with a zero
                throw new Exception("Connot Divide By Zero");
            }
            else
            {
                return (a / b);
            }
        }
        //returns A multiplyed by B
        public static double Multi(double a, double b)
        {
            return (a * b);
        }
    }
}
