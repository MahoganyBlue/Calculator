﻿//James Richards
//06/07/2019
//version 1.0
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trigonometric
{
    public class Class
    {
        //math libarary used because of too many variables to take into account when
        //calculating a trigonometric function. For example when Cos(60) is to be calculated
        //it must be divided by 0.5 but if you wanted to do Cos(54) 54 would have to be multipled
        //by 1.111111 to reach 60 then the result would need to be divided by 1.111111 again. The
        //0.5 of 60 changes with other values for example: 45= 1/SQRT2, 30= SQRT3/2
        public static double Cos(double a)
        {
            return Math.Cos(a);
        }
        public static double Tan(double a)
        {
            return Math.Tan(a);
        }
        public static double Sin(double a)
        {
            return Math.Sin(a);
        }

    }
}
