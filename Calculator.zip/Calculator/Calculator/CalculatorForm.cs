﻿// James Richards
// 06/07/2019
// Version 1.0

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class CalculatorForm : Form
    {
        public CalculatorForm()
        {
            InitializeComponent();
        }
        //Adds a zero to the txtDisplay box
        private void btnZero_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnZero.Text;
        }
        //Adds a one to the txtDisplay box
        private void btnOne_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnOne.Text;
        }
        //Adds a two to the txtDisplay box
        private void btnTwo_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnTwo.Text;
        }
        //Adds a three to the txtDisplay box
        private void btnThree_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnThree.Text;
        }
        //Adds a four to the txtDisplay box
        private void btnFour_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnFour.Text;
        }
        //Adds a five to the txtDisplay box
        private void btnFive_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnFive.Text;
        }
        //Adds a six to the txtDisplay box
        private void btnSix_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnSix.Text;
        }
        //Adds a seven to the txtDisplay box
        private void btnSeven_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnSeven.Text;
        }
        //Adds a eight to the txtDisplay box
        private void btnEight_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnEight.Text;
        }
        //Adds a nine to the txtDisplay box
        private void btnNine_Click(object sender, EventArgs e)
        {
            txtDisplay.Text = txtDisplay.Text + btnNine.Text;
        }

        //clears the txtDisplaybox and sets firstValue and secondValue to zero
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
            firstValue = 0;
            secondValue = 0;
        }
        //adds a '.' to the txtDisplay box
        private void btnPoint_Click(object sender, EventArgs e)
        {
            if (!(txtDisplay.Text.Contains(".")))
                txtDisplay.Text = txtDisplay.Text + btnDot.Text;
        }

        //
        //firstValue and secondValue are used to store the two numbers that are being calculated.
        double firstValue = 0;
        double secondValue = 0;
        //The button clicked values are used to see witch calculation the firstValue and secondValue 
        //will be used in. They are set in their respective button methods to turn true when thier
        //button is clicked
        bool plusButtonClicked = false;
        bool minusButtonClicked = false;
        bool divideButtonClicked = false;
        bool multiplyButtonClicked = false;
        bool TanButtonClicked = false;
        bool SinButtonClicked = false;
        bool CosButtonClicked = false;

        //sets txtbox value to firstValue then clears txtbox
        private void setfirstValue()
        {
            try
            {
                firstValue += double.Parse(txtDisplay.Text);//txtbox -> firstValue
                txtDisplay.Clear();
            }
            catch (Exception x)
            {
                txtDisplay.Text = "Invalid Number" + x;//if parse throws error
            }
        }

        //if the equals button is pressed the program must decide which calculation to make. The btnclicked
        //variables will only true for one. That one true variable will be used to idetify which calculation
        //will be used. in the if/else if statments each is assigned to to a btnclicked variable.
        private void btnEquals_Click(object sender, EventArgs e)
        {
            if (plusButtonClicked == true)//firstValue + secondValue
            {
                if (txtDisplay.Text != "")
                    secondValue = Arithmetic.Class.Add(firstValue, double.Parse(txtDisplay.Text));
                txtDisplay.Text = secondValue.ToString();
            }
            else if (minusButtonClicked == true)//firstValue - secondValue
            {
                if (txtDisplay.Text != "")
                    secondValue = Arithmetic.Class.Sub(firstValue, double.Parse(txtDisplay.Text));
                txtDisplay.Text = secondValue.ToString();
            }
            else if (divideButtonClicked == true)//firstValue / secondValue
            {
                double temp = double.Parse(txtDisplay.Text);
                if (txtDisplay.Text != "" && temp != 0)
                {
                    secondValue = Arithmetic.Class.Div(firstValue, temp);
                    txtDisplay.Text = secondValue.ToString();
                }
                else
                {
                    txtDisplay.Text = "Cannot Divid by Zero";
                }
                
            }
            else if (multiplyButtonClicked == true)//firstValue * secondValue
            {
                if (txtDisplay.Text != "")
                    secondValue = Arithmetic.Class.Multi(firstValue, double.Parse(txtDisplay.Text));
                txtDisplay.Text = secondValue.ToString();
            }
            else if (SinButtonClicked == true)//Sin(txtbox(secondLine))
            {
                String[] lines = txtDisplay.Lines;
                try { secondValue = Trigonometric.Class.Sin(double.Parse(lines[1])); }
                catch (Exception x) { }
                txtDisplay.Text = secondValue.ToString();
            }
            else if (TanButtonClicked == true)//Tan(txtbox(secondLine))
            {
                String[] lines = txtDisplay.Lines;
                if (!(lines[1].Contains("90") || lines[1].Contains("270")))//90 and 270 are not valid inputs
                {
                    try { txtDisplay.Text = Trigonometric.Class.Tan(double.Parse(lines[1])).ToString(); }
                    catch (Exception x) { }
                }
                else { txtDisplay.Text = "Invalid value"; }
            }
            else if (CosButtonClicked == true)//Cos(txtbox(secondLine))
            {
                String[] lines = txtDisplay.Lines;
                try { secondValue = Trigonometric.Class.Cos(double.Parse(lines[1])); }
                catch (Exception) { }
                txtDisplay.Text = secondValue.ToString();
            }
            secondValue = 0;
        }

        //Arithmetic buttons
        //The Button event methods set the button clicked values so once the equals button is pressed
        //the process can find which calculation is needed. they also set the firstValue for the calculation.
        private void btnPlus_Click(object sender, EventArgs e)
        {
            setfirstValue();//set firstValue method
            txtDisplay.Clear();
            plusButtonClicked = true;
            minusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }
        private void btnMinus_Click(object sender, EventArgs e)
        {
            setfirstValue();//set firstValue method
            txtDisplay.Clear();
            plusButtonClicked = false;
            minusButtonClicked = true;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
        }
        private void btnDiv_Click(object sender, EventArgs e)
        {
            setfirstValue();//set firstValue method
            txtDisplay.Clear();
            plusButtonClicked = false;
            minusButtonClicked = false;
            divideButtonClicked = true;
            multiplyButtonClicked = false;
        }
        private void btnmulti_Click(object sender, EventArgs e)
        {
            setfirstValue();//set firstValue method
            txtDisplay.Clear();
            plusButtonClicked = false;
            minusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = true;
        }

        //Trigonometric buttons
        //The difference for the trigonometric buttons from the arithmetic is that the 'sin(','Tan(' and 'Cos('
        //prompts are put on the first line then the curser is moved to the next line so a number can be entered.
        //This allows for a prompt for the user, and for the application to read the second line to get the value
        //instead of searching through the first line for a value.
        private void btnSIN_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
            plusButtonClicked = false;
            minusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
            SinButtonClicked = true;
            TanButtonClicked = false;
            CosButtonClicked = false;
            txtDisplay.Text = "Sin(";//Sin( prompt
            txtDisplay.AppendText(Environment.NewLine);//next line
        }
        private void btnTAN_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
            plusButtonClicked = false;
            minusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
            SinButtonClicked = false;
            TanButtonClicked = true;
            CosButtonClicked = false;
            txtDisplay.Text = "Tan(";//Tan( prompt
            txtDisplay.AppendText(Environment.NewLine);//next line
        }
        private void btnCOS_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
            plusButtonClicked = false;
            minusButtonClicked = false;
            divideButtonClicked = false;
            multiplyButtonClicked = false;
            SinButtonClicked = false;
            TanButtonClicked = false;
            CosButtonClicked = true;
            txtDisplay.Text = "Cos(";//Cos( prompt
            txtDisplay.AppendText(Environment.NewLine);//next line
        }

        //Algebraic buttons
        //The Algebraic buttons are seperate from the equals button because on a common calculator
        //when an Algebraic button is pressed the equation is done without pressing equals.
        //each button is seperate from the others and can be repeatedly pressed till the number reaches one.
        private void btnCube_Click(object sender, EventArgs e)
        {
            double num = 0;
            try//if no number is entered parse will cause error
            {
                num = double.Parse(txtDisplay.Text);
            }
            catch (Exception x)
            {
                txtDisplay.Text = "Number must be positive";
            }
            if (num >= 0)
            {
                //cube number from txtbox and return to txtbox
                txtDisplay.Text = Algebratic.Class.Cube(num).ToString();
            }
        }
        private void btnInver_Click(object sender, EventArgs e)
        {
            double num = 0;
            try//if no number is entered parse will cause error
            {
                num = double.Parse(txtDisplay.Text);
            }
            catch (Exception x)
            {
                txtDisplay.Text = "Number must be positive";
            }
            if (num >= 0)
            {
                //inver method can throw exception this is why a try catch is needed.
                //exception is printed to txtdisplay if an error has occured
                try { txtDisplay.Text = Algebratic.Class.Inver(num).ToString(); }
                catch (Exception x) { txtDisplay.Text = x.ToString(); }
            }
        }
        //Add comments here that explain the Sqrt method
        private void btnSqrt_Click(object sender, EventArgs e)
        {
            double num = 0;
            if (txtDisplay.Text != "")
            {
                try//if no number is entered parse will cause error
                {
                    num = double.Parse(txtDisplay.Text);
                }
                catch (Exception x)
                {
                    txtDisplay.Text = "Number must be positive";
                }
            }
            if (num > 0)
            {
                txtDisplay.Text = SquareRoot(num).ToString();
            }
            else
            {   
                //To square root a number the number must be above zero
                MessageBox.Show("Number must be above zero", "Error Message");
            }
        }

        /// <summary>
        /// Uses the square root function in the Algebraic libaray to find the Square root of the given double
        /// </summary>
        /// <param name="x">Requires a double value</param>
        /// <returns>Double value of the square root</returns>
        private double SquareRoot(double x)
        {
            secondValue = Algebratic.Class.SQRT(x);
            return secondValue;
        }

        //A menu strip that includes a quit option and a clear txtbox option
        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //open messagebox asking if they want to quit.
            if (MessageBox.Show("Really Quit?", "Exit", MessageBoxButtons.OKCancel) ==
           DialogResult.OK)
            {
                Application.Exit();
            }
        }
        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
        }
    }
}

